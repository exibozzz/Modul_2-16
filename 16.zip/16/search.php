
<!DOCTYPE html>

<html lang="en">

	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Search Product</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
		<script src="js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>


	<body>

		<form class="d-flex flex-column col-12 justify-content-center align-items-center bg-secondary " method="POST" action="models/searchProductModel.php" >
			<p class="display-4 mt-1">Search Product</p>
			<input class="form-control col-3 mb-3" type="text" name="search" placeholder="Search by product name or product description" required>
			<button class="btn btn-success mb-3 border border-white col-1">Search</button>
		</form>

	</body>

</html>
