<?php

?>

<!DOCTYPE html>
<html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Login</title>
            <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
            <script src="js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="css/style.css">
        </head>
        <body>


        <form class="d-flex justify-content-center align-items-center flex-column col-12 bg-secondary" method="POST" action="models/loginModel.php" >

                    <p class="display-4">Login</p>
                    
                    <div class="form-group col-3">
                        <label for="email" class="col-12">Email</label>
                        <input type="text" name="email" class="form-control col-12" id="email" placeholder="Enter your email" required>
                    </div>
                    <div class="form-group col-3">
                        <label for="password" class="col-12">Password</label>
                        <input type="password" name="password" class="form-control col-12 mb-2" id="lastName" placeholder="Enter your password" required>
                    </div>
                  
                    <button type="submit" class="btn btn-primary col-2 mb-3">Login</button>
                    <a href="registration.php" class="display-5 text-white">Register</a>
        </form> 
            
        </body>
</html>
