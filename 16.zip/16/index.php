<?php

         require_once "models/baza.php";

         $products = $baza->query("SELECT * FROM products");

         $assocProducts = $products->fetch_all(MYSQLI_ASSOC);

?>



<!DOCTYPE html>

        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>All Products</title>
            <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
            <script src="js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="css/style.css">
        </head>
        <body>
                        
                <div class="container bg-info ">
                    <p class="display-4">All Products</p>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Procurement Date</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Link</th>

                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach($assocProducts as $product): ?>
                                  <tr>                                     
                                        <td><?= $product['id'] ?></td>
                                        <td><?= $product['name'] ?></td>
                                        <td><?= $product['description'] ?></td>
                                        <td><?= $product['price'] ?></td>
                                        <td><?= $product['procurement_date'] ?></td>
                                        <td><?= $product['amount'] ?></td>  

                                        <td>
                                        <?php if($product['amount'] == 0):?>
                                            <p>N/A</p>
                                        <?php else:?>
                                            <p>Ima na stanju</p>
                                        <?php endif;?>   
                                        </td>  
                                        <td><a href="product.php?id=<?=$product['id']?>" class="text-white">See Product</a></td>
                                  </tr>
                                <?php endforeach; ?>
                            </tbody>

                        </table>
                    </div>
                </div>


        
            
        </body>
        </html>