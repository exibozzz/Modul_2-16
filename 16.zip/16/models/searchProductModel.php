<?php


        if(!isset($_POST['search']) || empty($_POST['search'])) {
            die("You need to insert search value.");
        }

        require_once "../models/baza.php";

        $searchProduct = $_POST['search'];

        $checkProducts = $baza->query(" SELECT * FROM products WHERE name LIKE '%$searchProduct%' OR description LIKE '%$searchProduct%' ");

        $foundedProductsInfo = $checkProducts->fetch_all(MYSQLI_ASSOC);


        if($checkProducts->num_rows >=1)
        {
            foreach($foundedProductsInfo as $productInfo)
            echo "Results: {$productInfo['name']}";
      
        }
        else {
            echo "No product founded.";
        }

        
?>
