        <?php

        if(!isset($_POST['email']) || empty($_POST['email']))
        {
            die("You need to enter your email adress.");
        }

        if(!isset($_POST['password']) || empty($_POST['password']))
        {
            die("You need to enter your email adress.");
        }



        require_once "../models/baza.php";
        
        $email = $_POST['email'];
        $password = $_POST['password'];

        $checkEmail = $baza->query("SELECT * FROM users WHERE email = '$email'");

        $checkEmailAssoc = $checkEmail->fetch_assoc();



        if($checkEmail->num_rows == 0)
        {
            die("Your email is incorrect.");

        }

        
            $userPassword = $checkEmailAssoc['password'];

            $checkPassword = $baza->query("SELECT * FROM users WHERE password = '$userPassword' ");

            $checkPasswordAssoc = $checkPassword->fetch_assoc();
            

            if($checkPasswordAssoc['password'] == $password)
            {
                echo "You have been successfully loged in.";

            }
            
            else 
            {
                die ("Your password is incorrect.");
            }


        


 

      
        






        ?>